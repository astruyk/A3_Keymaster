V.1.0.0

This program is a quick script intended to make changing the keys on the server for different modlists as hands-free as possible.

See https://github.com/astruyk/A3_ServerManager/wiki for usage instructions and details.